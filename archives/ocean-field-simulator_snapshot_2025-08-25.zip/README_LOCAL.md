# 🛠 Local Dev

## Быстрый старт (Docker)
1. cp .env.example .env
2. docker-compose up -d --build
3. Открой http://localhost:8080

## Без Docker
1. cd code
2. python3 -m http.server 8080
3. Открой http://localhost:8080
