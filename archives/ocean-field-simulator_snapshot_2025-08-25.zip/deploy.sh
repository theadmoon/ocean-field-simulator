#!/usr/bin/env bash
set -euo pipefail

echo "🚀 Starting Ocean2Joy deployment..."

# Requirements
command -v ssh >/dev/null 2>&1 || { echo "❌ ssh not found"; exit 1; }
command -v rsync >/dev/null 2>&1 || { echo "❌ rsync not found"; exit 1; }

# Load env
if [ -f .env ]; then
  set -a
  # shellcheck disable=SC2046
  export $(grep -v '^#' .env | xargs)
  set +a
else
  echo "❌ .env file not found"; exit 1
fi

: "${DEPLOY_HOST:?Missing DEPLOY_HOST in .env}"
: "${DEPLOY_USER:?Missing DEPLOY_USER in .env}"
: "${DEPLOY_PATH:?Missing DEPLOY_PATH in .env}"

SSH_HOST="$DEPLOY_USER@$DEPLOY_HOST"
SSH_OPTS="-o BatchMode=yes -o StrictHostKeyChecking=accept-new"

echo "🌐 Target: $SSH_HOST → $DEPLOY_PATH"

echo "🔑 Testing SSH connection..."
ssh $SSH_OPTS "$SSH_HOST" "echo ✅ SSH connection OK"

echo "🧹 Cleaning target directory on server..."
ssh $SSH_OPTS "$SSH_HOST" "rm -rf '$DEPLOY_PATH'/*"

EXCLUDES=(
  "--exclude=.git"
  "--exclude=.gitignore"
  "--exclude=node_modules"
  "--exclude=.venv"
  "--exclude=__pycache__"
  "--exclude=.DS_Store"
  "--exclude=Thumbs.db"
)

echo "📦 Copying via rsync..."
rsync -avz "${EXCLUDES[@]}" ./ "$SSH_HOST:$DEPLOY_PATH/" | tee deploy.log

echo "✅ Deployment finished. Log: deploy.log"
