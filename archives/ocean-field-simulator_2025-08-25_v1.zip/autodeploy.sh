#!/bin/bash
set -e

# === Настройки ===
PROJECT="ocean-field-simulator"
ARCHIVE_DIR="archives"
JOURNAL="PROJECT_JOURNAL.md"
DATE=$(date +"%Y-%m-%d")
TIME=$(date +"%H:%M:%S")
SSH_ALIAS="prod"
DEPLOY_PATH="/var/www/ocean2joy.com"
REPO_URL="git@github.com:theadmoon/$PROJECT.git"

# === 1. Проверка папки архивов ===
mkdir -p "$ARCHIVE_DIR"

# === 2. Определяем версию ===
LAST_VER=$(ls $ARCHIVE_DIR | grep "$PROJECT" | sed -E 's/.*_v([0-9]+)\.zip/\1/' | sort -n | tail -1)
if [ -z "$LAST_VER" ]; then
  VER=1
else
  VER=$((LAST_VER + 1))
fi
ARCHIVE_NAME="${PROJECT}_${DATE}_v${VER}.zip"

# === 3. Создаём архив версии ===
echo "📦 Creating archive: $ARCHIVE_NAME"
zip -r "$ARCHIVE_DIR/$ARCHIVE_NAME" . -x "$ARCHIVE_DIR/*" ".git/*"

# === 3.1. Создаём ежедневный снапшот (если ещё нет) ===
SNAPSHOT_NAME="${PROJECT}_snapshot_${DATE}.zip"
if [ ! -f "$ARCHIVE_DIR/$SNAPSHOT_NAME" ]; then
  echo "🗂 Creating daily snapshot: $SNAPSHOT_NAME"
  zip -r "$ARCHIVE_DIR/$SNAPSHOT_NAME" . -x "$ARCHIVE_DIR/*" ".git/*"
else
  echo "ℹ️ Snapshot for $DATE already exists: $SNAPSHOT_NAME"
fi

# === 4. Обновляем журнал ===
echo "- $DATE $TIME → v$VER archived and deployed" >> "$JOURNAL"

# === 5. GitHub push ===
echo "🚀 Pushing to GitHub..."
git add .
git commit -m "Auto-deploy v$VER ($DATE $TIME)"
git push origin main

# === 6. Загружаем архив в GitHub Releases ===
echo "📤 Uploading archive to GitHub Releases..."
gh release create "v$VER" "$ARCHIVE_DIR/$ARCHIVE_NAME" --title "Release v$VER" --notes "Auto-deploy on $DATE $TIME"

# === 7. Деплой на сервер ===
echo "🌐 Deploying to $SSH_ALIAS ($DEPLOY_PATH)..."
rsync -avz --delete   --exclude ".git"   --exclude "$ARCHIVE_DIR"   ./ "$SSH_ALIAS:$DEPLOY_PATH"

# === 8. Завершение ===
echo "✅ Deployment complete: v$VER"
echo "$DATE $TIME - Deployed v$VER" >> deploy.log
